# Julien Dutheil <Julien.Dutheil@univ-montp2.fr>
# 06/06/2006
# 15/11/2007

# ----------------------------------------------------------------------------------------------------------------
# Parameters to edit:
# ----------------------------------------------------------------------------------------------------------------

# File paths.
# Warning: Method names (within [[ ]]) must match between 1) and 2).

# 1) Clustering output

all.data.files<-list()
all.data.files[["Simple"]]    <-"../Coe/Simple/MAP_groups.csv"
all.data.files[["Grantham"]]  <-"../Coe/Grantham/MAP_groups.csv"
all.data.files[["Volume"]]    <-"../Coe/Volume/MAP_groups.csv"
all.data.files[["Polarity"]]  <-"../Coe/Polarity/MAP_groups.csv"
all.data.files[["Charge"]]    <-"../Coe/Charge/MAP_groups.csv"


# 2) Simulations

all.sim.files<-list()
all.sim.files[["Simple"]]    <-"../Coe/Simple/MAP_simulations.csv"
all.sim.files[["Grantham"]]  <-"../Coe/Grantham/MAP_simulations.csv"
all.sim.files[["Volume"]]    <-"../Coe/Volume/MAP_simulations.csv"
all.sim.files[["Polarity"]]  <-"../Coe/Polarity/MAP_simulations.csv"
all.sim.files[["Charge"]]    <-"../Coe/Charge/MAP_simulations.csv"

# 3) Output files:
output.file1<-"MAP_predictions_pvalues_all.csv"

#Sliding windows sizes:
window.Nmin=0.2
window.Delta=0.2

# General options:

#Maximum group size to test:
maxgs<-10
#Maximum p-value level or groups in the output files:
level<-1.
#Correction for nested groups:
cng<-TRUE
#Log file ("" = terminal)
logFile<-"Cliques.txt"

# ----------------------------------------------------------------------------------------------------------------
# END OF PARAMETER TO EDIT
# ----------------------------------------------------------------------------------------------------------------

source("CoMapFunctions.R")

methods=names(all.data.files)
if(any(methods != names(all.sim.files))) {
 stop("Method names do not match in data and simulations.")
} else {
  
all.data<-list()
for(m in methods)
{
  cat("Reading groups for method", m, ".\n")
  all.data[[m]]<-read.table(all.data.files[[m]], header=T, sep="\t")
}

all.sim<-list()
for(m in methods)
{
  cat("Reading simulations for method", m, ".\n")
  all.sim[[m]]<-read.table(all.sim.files[[m]], header=T, sep="\t")
}

all.pred<-list()
for(m in methods)
{
  cat("Testing method", m, ".\n")
  all.pred[[m]]<-get.pred(all.data[[m]], all.sim[[m]], 2:maxgs, window.Nmin, m, level, cng, logFile)
}

# Merging all results:
cat("Merging results for all methods.\n")
detected<-character(0)
for(m in methods)
{
  if(nrow(all.pred[[m]]) > 0) detected<-c(detected, m);
}
if(length(detected) > 0)
{
  pred<-all.pred[[detected[1]]]
  if(length(detected) > 1)
  {
    for(i in 2:length(detected))
    {
      pred<-merge(pred, all.pred[[detected[i]]], all=T)
    }
  }
  write.table(pred, file=output.file1, sep="\t", row.names=F, quot=F)
}
else
{
  cat("No group detected!\n");
}

} #END

