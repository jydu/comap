#! /bin/sh

DATA=LSU
	
echo "Analysing dataset $DATA."

echo "Running CoMap with unweighted mapping:"
comap param=${DATA}.coe \
      nijt=simple \
      output.vectors.file=Simple/${DATA}.vec \
      clustering.output.tree.file=Simple/${DATA}_clust.dnd \
      clustering.output.groups.file=Simple/${DATA}_groups.csv \
      clustering.null.output.file=Simple/${DATA}_simulations.csv 


echo "Done."

